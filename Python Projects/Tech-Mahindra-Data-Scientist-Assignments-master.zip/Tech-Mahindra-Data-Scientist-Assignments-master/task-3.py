# -*- coding: utf-8 -*-
"""
Created on Fri May 26 23:22:51 2017

@author: dipak
"""

text = open('data.dat', 'r')
string = text.read().split('\n')
string = [mylis.replace(',','') for mylis in string]
string = [mylis.replace('.',' ') for mylis in string]
a=[]
b=[]
d=[]
count=1
for line in string:
    line = line.rstrip()
    words = line.split()
    a.append(words[2])
    b.append(words[3]+" "+words[4]+" "+words[2]+" "+words[1]+" "+'{:02d}'.format(count))
    count+=1
    b.sort()

places = list(set(a))
i=1
j=1
k=1
for line in b:
    line = line.rstrip()
    words = line.split()
    if words[2] == places[0]:
        c = words[2]+'{:02d}'.format(i)+"."+words[3]
        d.append(words[4]+" "+c)
        i+=1
    if words[2] == places[1]:
        c = words[2]+'{:02d}'.format(j)+"."+words[3]
        d.append(words[4]+" "+c)
        j+=1
    if words[2] == places[2]:
        c = words[2]+'{:02d}'.format(k)+"."+words[3]
        d.append(words[4]+" "+c)
        k+=1
d.sort()

for line in d:
    line = line.rstrip()
    words = line.split()
    print words[1]


















